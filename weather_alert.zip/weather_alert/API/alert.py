from bs4 import BeautifulSoup as bs
import urllib.request
import json, re

"""all url"""
AL_URL = "https://www.jma.go.jp/bosai/common/const/area.json"
url = "https://www.jma.go.jp/bosai/warning/data/warning/%s.json"
"""-------"""

class weather:
    def __init__(self, codes):
        self.codes = codes

    def weather_(self):
        #コードと名称の取得
        soup = bs(urllib.request.urlopen("https://www.jma.go.jp/bosai/warning/#area_type=class20s&area_code=%s&lang=ja" % (self.codes)).read(), "html.parser")
        content = soup.find_all('script')[10]
        txt_list = str(content).split("},")
        lists = [re.findall(r'\w+', warning) for warning in txt_list if ':{name1:"' in warning]
        trans_warning = {}

        for datas in lists:
            text = ''
            for data in datas:
                if data in 'elem':
                    break
                if data in ['c', 'name1', 'name2']:
                    continue
                if data.isdecimal():
                    code = data
                    continue
                text += '\\' + data
        trans_warning[code] = text.encode('ascii').decode('unicode-escape')

        #情報の取得
        al_data = urllib.request.urlopen(url=AL_URL)
        al_data = json.loads(al_data.read())
        alert = al_data["class20s"][self.codes]["name"]
        class15s_area_code = al_data['class20s'][self.codes]['parent']
        class10s_area_code = al_data['class15s'][class15s_area_code]['parent']
        offices_area_code = al_data['class10s'][class10s_area_code]['parent']
        info = urllib.request.urlopen(url=url % (offices_area_code))
        info = json.loads(info.read())
        code_ = [Warning["code"]
                for class_area in info["areaTypes"][1]["areas"]
                if class_area["code"] == self.codes
                for warning in class_area["warnings"]
                if warning["status"] != "解除" and warning["status"] != "発表警報・注意報はなし"]
        warning_texts = [trans_warning[code] for code in code_]
        return (warning_texts,alert)
    
    def put(self):
        warning_texts,alert = self.weather_()
        print("https://www.jma.go.jp/bosai/warning/#area_type=class20s&area_code=%s&lang=ja" % (self.codes))
        print("%sの気象警報・注意報" % alert)
        if warning_texts:
                print("\n".join(warning_texts))
        else:
                print("現在発表警報・注意報はありません。")