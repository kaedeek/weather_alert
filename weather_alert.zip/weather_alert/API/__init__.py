from .alert import weather

__copyright__ = "Copyright 2024 kaede"
__version__ = "1.0.0"
__author__ = "kaede"

__all__ = ["weather"]