from API.alert import weather

def main():
    codes = weather("4732400") #市町村区のコード
    weather.weather_(codes)
    weather.put(codes)

if __name__ == "__main__":
    main()